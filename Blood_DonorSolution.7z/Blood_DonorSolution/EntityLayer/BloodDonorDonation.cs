﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityLayer
{
  public class BloodDonorDonation
    {
      
       
            public string BloodDonationID { get; set; }
            public string BloodDonorID { get; set; }
            public DateTime BloodDonationDate { get; set; }
            public int NumberOfBottles { get; set; }
            public float Weight { get; set; }
            public float HBCount { get; set; }
        



    }
}
